<?php

namespace App\Services\ECommerce;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\ProductVariant;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\SalePayment;
use App\Models\StockReservation;
use App\Services\StockService;
use App\Services\Payments\MercadoPagoService;
use Illuminate\Support\Facades\DB;

class OrderService
{
    public function createOrderAndReserve(int $companyId, ?int $customerId, array $items, int $reserveMinutes = 30): Order
    {
        return DB::transaction(function () use ($companyId, $customerId, $items, $reserveMinutes) {
            $order = Order::create([
                'company_id' => $companyId,
                'customer_id' => $customerId,
                'status' => 'pending', // pending|paid|cancelled
                'payment_status' => 'unpaid', // unpaid|approved|rejected|refunded
                'currency' => 'ARS',
                'channel' => 'web',
                'total' => 0,
            ]);

            $total = 0;
            foreach ($items as $it) {
                /** @var ProductVariant $variant */
                $variant = ProductVariant::where('company_id', $companyId)->where('id', $it['variant_id'])->firstOrFail();
                $qty = (float)$it['qty'];
                $unit = isset($it['unit_price']) ? (float)$it['unit_price'] : (float)$variant->price;
                $line = $qty * $unit;
                $total += $line;

                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $variant->product_id,
                    'variant_id' => $variant->id,
                    'description' => $it['description'] ?? null,
                    'qty' => $qty,
                    'unit_price' => $unit,
                    'line_total' => $line,
                ]);
            }

            $order->update(['total' => $total]);

            // Reservar stock en depósito central para cada ítem
            $stock = app(StockService::class);
            foreach ($order->items as $item) {
                $stock->reserveForWeb($companyId, (int)$item->variant_id, (float)$item->qty, $reserveMinutes, 'order', $order->id);
            }

            return $order->load('items');
        });
    }

    public function createMercadoPagoPreference(Order $order, string $successUrl, string $failureUrl, string $pendingUrl, string $webhookUrl): array
    {
        $mp = app(MercadoPagoService::class);

        $items = [];
        foreach ($order->items as $it) {
            $items[] = [
                'title' => $it->description ?: ('Item '.$it->variant_id),
                'quantity' => (int) ceil($it->qty), // MP requiere integer en muchos casos; ajustar si vendés fraccionado.
                'unit_price' => (float) $it->unit_price,
                'currency_id' => $order->currency ?: 'ARS',
            ];
        }

        $payload = [
            'external_reference' => (string) $order->id,
            'items' => $items,
            'notification_url' => $webhookUrl,
            'back_urls' => [
                'success' => $successUrl,
                'failure' => $failureUrl,
                'pending' => $pendingUrl,
            ],
            'auto_return' => 'approved',
        ];

        return $mp->createPreference($payload);
    }

    /**
     * Finaliza un pedido pagado: convierte a Sale, confirma reservas y registra pago.
     */
    public function markOrderPaidFromMercadoPago(int $companyId, int $orderId, array $payment): Sale
    {
        return DB::transaction(function () use ($companyId, $orderId, $payment) {
            /** @var Order $order */
            $order = Order::where('company_id', $companyId)->where('id', $orderId)->lockForUpdate()->firstOrFail();

            if ($order->payment_status === 'approved' || $order->status === 'paid') {
                // idempotencia
                $sale = Sale::where('order_id', $order->id)->first();
                if ($sale) return $sale->load('items');
            }

            $order->update([
                'payment_status' => 'approved',
                'status' => 'paid',
            ]);

            // Crear Sale (canal web)
            $stockService = app(StockService::class);
            $warehouseId = $stockService->getCentralWarehouseIdForWeb($companyId);

            $sale = Sale::create([
                'company_id' => $companyId,
                'warehouse_id' => $warehouseId,
                'customer_id' => $order->customer_id,
                'order_id' => $order->id,
                'channel' => 'web',
                'sale_date' => now(),
                'status' => 'confirmed',
                'subtotal' => $order->total,
                'tax_total' => 0,
                'total' => $order->total,
                'currency' => $order->currency ?: 'ARS',
            ]);

            foreach ($order->items as $it) {
                $si = SaleItem::create([
                    'sale_id' => $sale->id,
                    'product_id' => $it->product_id,
                    'variant_id' => $it->variant_id,
                    'description' => $it->description,
                    'qty' => $it->qty,
                    'unit_price' => $it->unit_price,
                    'discount' => 0,
                    'tax_id' => null,
                    'tax_rate' => null,
                    'tax_amount' => 0,
                    'line_total' => $it->line_total,
                ]);

                // Confirmar reserva(s) del pedido para esa variante
                $reservations = StockReservation::where('company_id', $companyId)
                    ->where('reference_type', 'order')
                    ->where('reference_id', $order->id)
                    ->where('variant_id', $it->variant_id)
                    ->where('status', 'active')
                    ->get();

                foreach ($reservations as $res) {
                    $stockService->commitReservation($res, 'sale_item', $si->id);
                }
            }

            // Registrar pago
            SalePayment::create([
                'company_id' => $companyId,
                'sale_id' => $sale->id,
                'order_id' => $order->id,
                'provider' => 'mercadopago',
                'provider_payment_id' => (string)($payment['id'] ?? ''),
                'status' => (string)($payment['status'] ?? 'unknown'),
                'amount' => (float)($payment['transaction_amount'] ?? $order->total),
                'currency' => (string)($payment['currency_id'] ?? ($order->currency ?: 'ARS')),
                'raw' => $payment,
            ]);

            return $sale->load('items');
        });
    }
}
