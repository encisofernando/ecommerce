<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    protected $fillable = [
        'order_id','product_id','variant_id','description','qty','unit_price','line_total'
    ];

    protected $casts = [
        'qty'=>'float',
        'unit_price'=>'float',
        'line_total'=>'float',
    ];

    public function order(){ return $this->belongsTo(Order::class); }

    public function variant(){ return $this->belongsTo(ProductVariant::class, 'variant_id'); }
}
