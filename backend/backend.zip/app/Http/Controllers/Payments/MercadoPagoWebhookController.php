<?php

namespace App\Http\Controllers\Payments;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Services\Payments\MercadoPagoService;
use App\Services\ECommerce\OrderService;

class MercadoPagoWebhookController extends Controller
{
    /**
     * Webhook (topic payment). Mercado Pago envía data.id con el payment id.
     * Se debe responder 200/201 rápidamente y luego consultar el pago por API.
     */
    public function handle(Request $r, MercadoPagoService $mp, OrderService $orders)
    {
        // Validación opcional de firma (recomendado)
        $dataId = (string)($r->input('data.id') ?? '');
        $xSig = $r->header('x-signature');
        $xReq = $r->header('x-request-id');

        $valid = $mp->validateWebhookSignature($xSig, $xReq, $dataId);

        if (config('mercadopago.webhook_secret') && !$valid) {
            return response()->json(['message'=>'Invalid signature'], 401);
        }

        // Solo procesamos pagos
        if (($r->input('type') ?? $r->input('topic')) !== 'payment') {
            return response()->json(['ok'=>true], 200);
        }

        if (!$dataId) {
            return response()->json(['ok'=>true], 200);
        }

        // Consultar pago completo
        $payment = $mp->getPayment($dataId);

        // external_reference = order_id (string)
        $orderId = (int)($payment['external_reference'] ?? 0);

        // Por ahora: solo si aprobado
        if (($payment['status'] ?? '') === 'approved' && $orderId > 0) {
            // company_id debería venir del pedido; en un webhook público no tenemos auth.
            // Si manejás multiempresa, lo correcto es buscar el pedido para obtener company_id.
            $companyId = (int)\DB::table('orders')->where('id',$orderId)->value('company_id');
            if ($companyId > 0) {
                $orders->markOrderPaidFromMercadoPago($companyId, $orderId, $payment);
            }
        }

        return response()->json(['ok'=>true], 200);
    }
}
