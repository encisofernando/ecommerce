<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\InvoiceType;
use App\Models\Sale;
use App\Services\EInvoicing\ArcaWsfeService;

class InvoicesController extends Controller
{
    /**
     * Crea factura desde una venta y autoriza en ARCA/AFIP (WSFEv1).
     * Requiere: sale_id, invoice_type_code (A|B|C|M), pos_number (Punto de venta)
     */
    public function store(Request $r, ArcaWsfeService $wsfe)
    {
        $cid = (int)$r->user()->company_id;

        $data = $r->validate([
            'sale_id' => 'required|integer',
            'invoice_type_code' => 'required|string|max:5',
            'pos_number' => 'required|integer',
            'doc_tipo' => 'sometimes|integer', // 80 CUIT, 96 DNI, 99 CF
            'doc_nro' => 'sometimes|numeric',
        ]);

        /** @var Sale $sale */
        $sale = Sale::where('company_id',$cid)->where('id',$data['sale_id'])->with('items.variant')->firstOrFail();

        if ($sale->status === 'invoiced') {
            return response()->json(['message'=>'La venta ya está facturada'], 409);
        }

        $invType = InvoiceType::where('company_id',$cid)->where('code',$data['invoice_type_code'])->first();
        if (!$invType) {
            // fallback: crear tipo si no existe
            $invType = InvoiceType::create([
                'company_id'=>$cid,
                'code'=>$data['invoice_type_code'],
                'name'=>'Factura '.$data['invoice_type_code'],
            ]);
        }

        $cbteTipo = $this->mapCbteTipo($data['invoice_type_code']);

        $invoice = DB::transaction(function () use ($cid,$sale,$invType,$data,$wsfe,$cbteTipo) {
            $issueDate = now();

            $invoice = Invoice::create([
                'company_id' => $cid,
                'sale_id' => $sale->id,
                'invoice_type_id' => $invType->id,
                'pos_number' => (int)$data['pos_number'],
                'issue_date' => $issueDate,
                'customer_name' => optional($sale->customer)->name ?? null,
                'subtotal' => $sale->subtotal ?? 0,
                'tax_total' => $sale->tax_total ?? 0,
                'total' => $sale->total ?? 0,
                'status' => 'pending',
            ]);

            foreach ($sale->items as $it) {
                InvoiceItem::create([
                    'invoice_id' => $invoice->id,
                    'product_id' => $it->product_id,
                    'description' => $it->description,
                    'qty' => $it->qty,
                    'unit_price' => $it->unit_price,
                    'tax_rate' => $it->tax_rate,
                    'line_total' => $it->line_total,
                ]);
            }

            // Emitir CAE (por ahora: IVA simplificado, podés extender a alícuotas reales)
            $resp = $wsfe->createVoucher([
                'cbte_tipo' => $cbteTipo,
                'concepto' => 1,
                'doc_tipo' => (int)($data['doc_tipo'] ?? 99),
                'doc_nro' => (float)($data['doc_nro'] ?? 0),
                'imp_total' => (float)$invoice->total,
                'imp_neto' => (float)$invoice->total,
                'imp_iva' => 0,
                'iva_alicuotas' => [],
                'cbte_fch' => $issueDate->format('Ymd'),
            ]);

            if (($resp['resultado'] ?? null) !== 'A' || empty($resp['cae'])) {
                $invoice->update([
                    'status' => 'rejected',
                    'arca_response' => $this->stringifySoap($resp['raw'] ?? null),
                ]);
                throw new \RuntimeException('ARCA rechazó el comprobante');
            }

            $invoice->update([
                'status' => 'authorized',
                'invoice_number' => $resp['cbte_nro'],
                'cae' => $resp['cae'],
                'cae_due_date' => $resp['cae_vto'] ?? null,
                'arca_response' => $this->stringifySoap($resp['raw'] ?? null),
            ]);

            $sale->update(['status' => 'invoiced']);

            return $invoice;
        });

        return $invoice->load('items');
    }

    private function mapCbteTipo(string $code): int
    {
        $code = strtoupper(trim($code));
        return match ($code) {
            'A' => 1,
            'B' => 6,
            'C' => 11,
            'M' => 51,
            default => 11,
        };
    }

    private function stringifySoap($raw): array
    {
        // SoapVar / objetos: convertir a array básico para guardar
        if (is_array($raw)) return $raw;
        if (is_object($raw)) return json_decode(json_encode($raw), true) ?: [];
        return [];
    }
}
